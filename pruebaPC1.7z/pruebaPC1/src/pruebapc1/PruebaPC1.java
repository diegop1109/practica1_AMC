/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebapc1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import puntos.Traza;
import puntos.Punto;

public class PruebaPC1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {

        File archivo = new File("D:\\UniversidadHuelva\\Primer Semestre\\Algoritmica\\dataset_PC1\\berlin52.tsp");
        FileReader fr = new FileReader(archivo);
        BufferedReader br = new BufferedReader(fr);
        int dimensiones = 0;
        ArrayList<Punto> ArrP = null;

        int cont = 0;
        int cont2 = 0;
        String cadena;
        while ((cadena = br.readLine()) != null) {
            StringTokenizer stn = new StringTokenizer(cadena);
            
            switch (cont) {
                case 0:
                    cont++;
                    break;
                case 1:
                    cont++;
                    break;
                case 2:
                    cont++;
                    break;
                case 3:
                    String name = stn.nextToken();
                    int rn = Integer.parseInt(stn.nextToken());
                    dimensiones = rn;
                    ArrP = new ArrayList<Punto>(dimensiones);
                    cont++;
                    break;
                case 4:
                    cont++;
                    break;
                case 5:
                    cont++;
                    break;
                case 6:
                    int id = Integer.parseInt(stn.nextToken());
                    double CoorX = Double.parseDouble(stn.nextToken());
                    double CoorY = Double.parseDouble(stn.nextToken());

                    if (cont2 < dimensiones) {
                        Punto a = new Punto(id, CoorX, CoorY);
                        ArrP.set(id, a);
                        cont2++;
                        if (cont2 == dimensiones) {
                            cont++;
                        }
                    }
                    break;
                case 7:
                    for (int i = 0; i < dimensiones; i++) {
                        System.out.println("Punto");
                        System.out.println("Nombre: " + ArrP.get(i).getId());
                        System.out.println("Coordenada X: " + ArrP.get(i).getX());
                        System.out.println("Coordenada Y: " + ArrP.get(i).getY());
                    }
                    break;
            }

        }

    }

}
