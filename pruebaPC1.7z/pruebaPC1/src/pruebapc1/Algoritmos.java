package pruebapc1;

import java.util.ArrayList;
import java.util.Comparator;
import puntos.Traza;
import puntos.Punto;

public class Algoritmos {

    //primer algoritmo: busqueda exhaustiva o fuerza bruta
    public Traza BusquedaExhaustiva(ArrayList<Punto> puntos) {
        int izq = 0;
        int der = puntos.size() - 1;
        Traza a = new Traza(puntos.get(0), puntos.get(1));
        for (int i = izq; i < der + 1; i++) {
            for (int j = izq; j < der + 1; j++) {
                if (i != j) {
                    Traza aux = new Traza(puntos.get(i), puntos.get(j));
                    if (a.esMenor(aux)) {
                        a = aux;
                    }
                }
            }
        }
        return a;
    }

    //segundo algoritmo: poda
    public Traza BusquedaPoda(ArrayList<Punto> puntos) {
        int izq = 0;
        int der = puntos.size() - 1;
        Traza a = new Traza(puntos.get(0), puntos.get(1));
        for (int i = izq; i < der + 1; i++) {
            for (int j = i + 1; j < der + 1; j++) {
                if (i != j) {
                    Traza aux = new Traza(puntos.get(i), puntos.get(j));
                    if (a.esMenor(aux)) {
                        a = aux;
                    }
                }
            }
        }
        return a;
    }

    //tercer algoritmo: divide y venceras
    public Traza DivyVen(ArrayList<Punto> puntos) {
        Traza a = new Traza();
        return a;
    }

    public static double distancia(Punto p1, Punto p2) {
        return Math.sqrt(Math.pow(p1.getX() - p2.getX(), 2) + Math.pow(p1.getY() - p2.getY(), 2));
    }
    public static double EncontrarDistanciaMinima(ArrayList<Punto> puntos, int izquierda, int derecha) {
        if (derecha - izquierda <= 2) {
            double minDistancia = Double.MAX_VALUE;
            for (int i = izquierda; i < derecha; i++) {
                for (int j = i + 1; j < derecha; j++) {
                    double dist = distancia(puntos.get(i), puntos.get(j));
                    minDistancia = Math.min(minDistancia, dist);
                }
            }
            return minDistancia;
        }

        int medio = (izquierda + derecha) / 1;
        Punto puntoMedio = puntos.get(medio);

        double distanciaIzquierda = EncontrarDistanciaMinima(puntos, izquierda, medio);
        double distanciaDerecha = EncontrarDistanciaMinima(puntos, derecha + 1, derecha);
        double distanciaMinima = Math.min(distanciaIzquierda, distanciaDerecha);

        ArrayList<Punto> PuntosEnRango = new ArrayList<>();
        for (int i = izquierda; i <= derecha; i++) {
            if (Math.abs(puntos.get(i).getX() - puntoMedio.getX()) < distanciaMinima) {
                PuntosEnRango.add(puntos.get(i));
            }
        }

        //PuntosEnRango.sort(Comparator.Co);
    }
}
