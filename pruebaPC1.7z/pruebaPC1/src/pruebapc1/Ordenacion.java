/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebapc1;

/**
 *
 * @author usuario
 */
public class Ordenacion {
    
    //ORDENACION POR QUICKSORT
    public void quickSort(int v[], int primero, int ultimo) {
        int pivote, posicion;
        
        if (primero < ultimo) {
            pivote = v[ultimo];
            posicion = partition(v, primero, ultimo, pivote);
            quickSort(v,primero,posicion-1);
            quickSort(v,posicion+1,ultimo);
        }
    }
    public int partition(int v[], int primero, int ultimo, int pivote) {
        int i=primero;
        int j=primero;
        
        while (i<=ultimo) {            
            if (v[i]>pivote) {
                i++;
            } else {
                intercambia(v,i,j);
                i++;
                j++;
            }
        }
        return j-1;
    }
    public void intercambia(int T[],int i, int j) {
        int temp=T[i];
        T[i]=T[j];
        T[j]=temp;
    }
}
