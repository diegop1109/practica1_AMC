/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Grafica;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.Reader;
import java.util.ArrayList;
import puntos.Traza;
import puntos.Punto;

/**
 *
 * @author diepa
 */
public class CanvasPC1 extends Canvas{
    ArrayList<Punto> puntos;
    Traza prueba;
    double[][] grafo;

    public CanvasPC1() {
    }

    public CanvasPC1(int ancho, int alto, ArrayList<Punto> puntos, Traza prueba, double[][] grafo) {
        this.setSize(ancho, alto);
        this.setBackground(Color.white);
        this.puntos = puntos;
        this.prueba = prueba;
        this.grafo = grafo;
    }

    @Override
    public void update(Graphics g) {
        paint(g);
    }

    @Override
    public void paint(Graphics g) {
        Font f1 = new Font("Arial", Font.BOLD + Font.ITALIC, 14);
        g.setColor(Color.black);
        for (int i = 0; i < puntos.size(); i++) {
            g.setFont(f1);
            g.fillOval((int) puntos.get(i).getX(), (int)puntos.get(i).getY(), 10, 10);
            g.drawString(i + 1 + "", (int)puntos.get(i).getX(), (int) puntos.get(i).getY() - 10);
        }
        
        if (prueba != null) {
            g.setColor(Color.red);
            g.fillOval((int) prueba.getP1().getX(), (int) prueba.getP1().getY(), 10, 10);
            g.fillOval((int) prueba.getP2().getX(), (int) prueba.getP2().getY(), 10, 10);
            g.drawLine((int) prueba.getP1().getX() + 7, (int)prueba.getP1().getY(), (int) prueba.getP2().getX() + 7, (int) prueba.getP2().getY());

        } else {

            for (int i = 0; i < puntos.size(); i++) {
                for (int j = 0; j < puntos.size(); j++) {
                    g.setFont(f1);
                    g.setColor(Color.blue);
                    Punto p = new Punto();
                    p.esCentro(puntos.get(i).getId(),puntos.get(i), puntos.get(j));
                    g.drawString(grafo[i][j] + "", (int) p.getX() + 7, (int) p.getY() + 7);
                    g.setColor(Color.cyan);
                    g.drawLine((int) puntos.get(i).getX() + 7, (int) puntos.get(i).getY(), (int) puntos.get(j).getX() + 7, (int) puntos.get(j).getY());

                }

            }
        }
    }
    
}
